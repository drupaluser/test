<?php
	/**
 	 * Implements hook_menu().
 	 */
	function my_form_menu() {
		$items = array();
		$items['admin/content/generation'] = array(
			'title' => 'Generation content',
			'page callback' => 'drupal_get_form',
			'page arguments' => array('page_form'),
			'access callback' => TRUE,

		);
		return $items;
 }

 	/**
 	 * Build generation form.
 	 */
 	function page_form($form, $form_state) {
 		/**$form = array(
 			$form['selected'] = array(
       		'#type' => 'select',
       		'#title' => t('What CT to create?'),
       		'#options' => array(
          	0 => t('Authors'),
         	1 => t('Books'),
       		),
   		);*/

		$form['number1'] = array(
  '#type' => 'textfield',
  '#title' => t('Number 1'),
  '#size' => 20,
);
$form['number2'] = array(
  '#type' => 'textfield',
  '#title' => t('Number 2'),
  '#size' => 20,
);
 	);
 		return $form;
 	}
?>